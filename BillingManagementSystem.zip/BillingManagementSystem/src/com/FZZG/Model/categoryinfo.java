package com.FZZG.Model;

public class categoryinfo {
       private String category;

       public categoryinfo() {
       }

       public categoryinfo(String category) {
              this.category = category;
       }

       public String getCategory() {
              return category;
       }

       public void setCategory(String category) {
              this.category = category;
       }
}
